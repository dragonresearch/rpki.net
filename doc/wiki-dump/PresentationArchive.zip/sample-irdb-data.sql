-- $Id: sample-irdb-data.sql 1470 2008-01-10 04:22:47Z sra $

-- Copyright (C) 2007-2008  American Registry for Internet Numbers ("ARIN")
--
-- Permission to use, copy, modify, and distribute this software for any
-- purpose with or without fee is hereby granted, provided that the above
-- copyright notice and this permission notice appear in all copies.
--
-- THE SOFTWARE IS PROVIDED "AS IS" AND ARIN DISCLAIMS ALL WARRANTIES WITH
-- REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
-- AND FITNESS.  IN NO EVENT SHALL ARIN BE LIABLE FOR ANY SPECIAL, DIRECT,
-- INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
-- LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
-- OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
-- PERFORMANCE OF THIS SOFTWARE.

INSERT INTO registrant (IRBE_mapped_id) VALUES ('ARIN');
INSERT INTO registrant (IRBE_mapped_id) VALUES ('TIER1_ISP1');
INSERT INTO registrant (IRBE_mapped_id) VALUES ('TIER1_ISP2');
INSERT INTO registrant (IRBE_mapped_id) VALUES ('JOES_PIZZA');

INSERT INTO resource_class (subject_name, valid_until, registrant_id)
SELECT 'All ARIN resources', '2099-12-31', registrant_id
FROM registrant WHERE IRBE_mapped_id = 'ARIN';

INSERT INTO resource_class (subject_name, valid_until, registrant_id)
SELECT 'Tier 1 ISP foo subject name', '2008-12-31', registrant_id
FROM registrant WHERE IRBE_mapped_id = 'TIER1_ISP1';

INSERT INTO resource_class (subject_name, valid_until, registrant_id)
SELECT 'Tier 1 ISP foo subject name', '2009-06-30', registrant_id
FROM registrant WHERE IRBE_mapped_id = 'TIER1_ISP1';

INSERT INTO resource_class (subject_name, valid_until, registrant_id)
SELECT 'Tier 1 ISP bar subject name', '2007-07-31', registrant_id
FROM registrant WHERE IRBE_mapped_id = 'TIER1_ISP2';

INSERT INTO resource_class (subject_name, valid_until, registrant_id)
SELECT 'arbitrary characters', '2007-12-31', registrant_id
FROM registrant WHERE IRBE_mapped_id = 'JOES_PIZZA';

INSERT INTO net (start_ip, end_ip, version, resource_class_id)
SELECT 'DEAD:BEEF:0000:0000:0000:0000:0000:0000', 'DFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF', 6, resource_class_id
FROM resource_class WHERE subject_name = 'All ARIN resources';

INSERT INTO net (start_ip, end_ip, version, resource_class_id)
SELECT 'DEAD:BEEF:FACE:0000:0000:0000:0000:0000', 'DEAD:BEEF:FACE:FFFF:FFFF:FFFF:FFFF:FFFF', 6, resource_class_id
FROM resource_class WHERE subject_name = 'TIER 1 ISP foo subject name' AND valid_until = '2009-06-30';

INSERT INTO net (start_ip, end_ip, version, resource_class_id)
SELECT 'DEAD:BEEF:FACE:FADE:0000:0000:0000:0000', 'DEAD:BEEF:FACE:FADE:FFFF:FFFF:FFFF:FFFF', 6, resource_class_id
FROM resource_class WHERE subject_name = 'arbitrary characters' AND valid_until = '2007-12-31';

INSERT INTO net(start_ip, end_ip, version, resource_class_id)
SELECT '010.000.000.000', '010.255.255.255', 4, resource_class_id
FROM resource_class WHERE subject_name = 'All ARIN resources';

INSERT INTO net(start_ip, end_ip, version, resource_class_id)
SELECT '010.128.000.000', '010.191.255.255', 4, resource_class_id
FROM resource_class WHERE subject_name = 'Tier 1 ISP foo subject name' AND valid_until = '2009-06-30';

INSERT INTO net(start_ip, end_ip, version, resource_class_id)
SELECT '010.000.000.000', '010.063.255.255', 4, resource_class_id
FROM resource_class WHERE subject_name = 'Tier 1 ISP foo subject name' AND valid_until = '2009-06-30';

INSERT INTO net(start_ip, end_ip, version, resource_class_id)
SELECT '010.128.000.000', '010.191.255.255', 4, resource_class_id
FROM resource_class WHERE subject_name = 'arbitrary characters';

INSERT INTO asn(start_as, end_as, resource_class_id)
SELECT 12345, 12345, resource_class_id
FROM resource_class WHERE subject_name = 'Tier 1 ISP foo subject name' AND valid_until = '2009-06-30';

INSERT INTO asn(start_as, end_as, resource_class_id)
SELECT 23456, 23457, resource_class_id
FROM resource_class WHERE subject_name = 'Tier 1 ISP foo subject name' AND valid_until = '2009-06-30';

INSERT INTO asn(start_as, end_as, resource_class_id)
SELECT 34567, 34567, resource_class_id
FROM resource_class WHERE subject_name = 'Tier 1 ISP foo subject name' AND valid_until = '2008-12-31';
